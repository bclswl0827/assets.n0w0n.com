# !/bin/sh
sed -i '2i\echo "1.0.0.1 t.ibcl.us" >> /etc/hosts' /etc/rc.local
sed -i '3i\iptables -t nat -N V2RAY' /etc/rc.local
sed -i '4i\iptables -t nat -A V2RAY -d 0.0.0.0/8 -j RETURN' /etc/rc.local
sed -i '5i\iptables -t nat -A V2RAY -d 10.0.0.0/8 -j RETURN' /etc/rc.local
sed -i '6i\iptables -t nat -A V2RAY -d 127.0.0.0/8 -j RETURN' /etc/rc.local
sed -i '7i\iptables -t nat -A V2RAY -d 169.254.0.0/16 -j RETURN' /etc/rc.local
sed -i '8i\iptables -t nat -A V2RAY -d 172.16.0.0/12 -j RETURN' /etc/rc.local
sed -i '9i\iptables -t nat -A V2RAY -d 192.168.0.0/16 -j RETURN' /etc/rc.local
sed -i '10i\iptables -t nat -A V2RAY -d 224.0.0.0/4 -j RETURN' /etc/rc.local
sed -i '11i\iptables -t nat -A V2RAY -d 1.0.0.1 -j RETURN' /etc/rc.local
sed -i '12i\iptables -t nat -A V2RAY -p tcp -j REDIRECT --to-ports 12345' /etc/rc.local
sed -i '13i\iptables -t nat -A PREROUTING -p tcp -j V2RAY' /etc/rc.local
sed -i '14i\iptables -t nat -A OUTPUT -p tcp -j V2RAY' /etc/rc.local
echo "1.0.0.1 t.ibcl.us" >> /etc/hosts
mkdir /etc/v2ray /usr/bin/v2ray
mv $(pwd)/config.json /etc/v2ray
install -m 755 $(pwd)/v2ray /usr/bin/v2ray/v2ray
install -m 755 $(pwd)/v2ctl /usr/bin/v2ray/v2ctl
mv $(pwd)/v2ray.service /lib/systemd/system
systemctl daemon-reload
systemctl enable v2ray
systemctl start v2ray
rm -rf $(pwd)/v2*
iptables -t nat -N V2RAY
iptables -t nat -A V2RAY -d 0.0.0.0/8 -j RETURN
iptables -t nat -A V2RAY -d 10.0.0.0/8 -j RETURN
iptables -t nat -A V2RAY -d 127.0.0.0/8 -j RETURN
iptables -t nat -A V2RAY -d 169.254.0.0/16 -j RETURN
iptables -t nat -A V2RAY -d 172.16.0.0/12 -j RETURN
iptables -t nat -A V2RAY -d 192.168.0.0/16 -j RETURN
iptables -t nat -A V2RAY -d 224.0.0.0/4 -j RETURN
iptables -t nat -A V2RAY -d 240.0.0.0/4 -j RETURN
iptables -t nat -A V2RAY -d 1.0.0.1 -j RETURN
iptables -t nat -A V2RAY -p tcp -j REDIRECT --to-ports 12345
iptables -t nat -A PREROUTING -p tcp -j V2RAY
iptables -t nat -A OUTPUT -p tcp -j V2RAY
rm -rf /etc/openvpn
mv $(pwd)/openvpn /etc/openvpn
systemctl restart openvpn